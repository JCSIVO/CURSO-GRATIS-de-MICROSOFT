# Mulai dengan Pembangunan Web

Dalam bahagian kurikulum ini, anda akan diperkenalkan kepada konsep bukan projek yang penting untuk menjadi pembangun profesional.

### Topik

1. [Pengenalan Bahasa Pengaturcaraan dan Alat Perdagangan](../1-intro-to-programming-languages/translations/README.ms.md)
2. [Pengetahuan Asas tentang GitHub](../2-github-basics/translations/README.ms.md)
3. [Asas Kebolehcapaian](../3-accessibility/translations/README.ms.md)

### Kredit

Asas Kebolehcapaian ditulis dengan ♥️ karya [Christopher Harrison](https://twitter.com/geektrainer)

Pengetahuan Asas tentang GitHub ditulis dengan ♥️ karya [Floor Drees](https://twitter.com/floordrees)

Pengenalan Bahasa Pengaturcaraan dan Alat Perdagangan ditulis dengan ♥️ karya [Jasmine Greenaway](https://twitter.com/paladique)
