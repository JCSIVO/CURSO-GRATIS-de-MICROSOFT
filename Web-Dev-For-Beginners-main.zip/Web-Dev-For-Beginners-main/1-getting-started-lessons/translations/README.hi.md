# वेब डेवलपमेंट के साथ शुरुआत करना

पाठ्यक्रम के इस खंड में, आपको पेशेवर डेवलपर बनने के लिए महत्वपूर्ण गैर-परियोजना आधारित अवधारणाओं से परिचित कराया जाएगा।

### विषय

1. [प्रोग्रामिंग भाषाओं और व्यापार के उपकरण का परिचय](../1-intro-to-programming-languages/translations/README.hi.md)
2. [गिटहब की मूल बातें](../2-github-basics/translations/README.hi.md)
3. [पहुँच की मूल बातें](../3-accessibility/translations/README.hi.md)

### क्रेडिट

एक्सेसिबिलिटी की मूल बातें [क्रिस्टोफर हैरिसन](https://twitter.com/geektrainer) द्वारा ♥️ से लिखा गया था

GitHub का परिचय [फ्लोर ड्रेस](https://twitter.com/floordrees) द्वारा ♥️ से लिखा गया था

प्रोग्रामिंग भाषाओं और व्यापार के उपकरण का परिचय  [जस्मिने ग्रीनवे](https://twitter.com/paladique) द्वारा ♥️ से लिखा गया था
