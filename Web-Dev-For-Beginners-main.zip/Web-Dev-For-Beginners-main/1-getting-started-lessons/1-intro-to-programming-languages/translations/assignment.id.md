# Membaca Dokumentasi

## Instruksi

Ada banyak alat yang mungkin diperlukan pengembang web yang ada di [dokumentasi MDN untuk alat sisi klien](https://developer.mozilla.org/docs/Learn/Tools_and_testing/Understanding_client-side_tools/Overview) . Pilih 3 alat yang tidak tercakup dalam pelajaran, jelaskan mengapa pengembang web akan menggunakannya, dan cari alat yang termasuk dalam kategori ini dan bagikan dokumentasinya. Jangan gunakan contoh alat yang sama pada dokumen MDN.

## Rubrik

| Teladan                                                  | Memenuhi Syarat                                                             | Perlu Perbaikan                                                                  |
|----------------------------------------------------------|-----------------------------------------------------------------------------|----------------------------------------------------------------------------------|
| Menjelaskan mengapa pengembang web akan menggunakan alat | Dijelaskan bagaimana, tetapi tidak mengapa pengembang akan menggunakan alat | Tidak disebutkan bagaimana atau mengapa seorang pengembang akan menggunakan alat |
