# Maak een nieuw toetsenbordspel

## Instructies

Maak een klein spel dat toetsenbordgebeurtenissen gebruikt om taken uit te voeren. Het kan een ander soort typespel zijn, of een kunstspel dat bij toetsaanslagen pixels op het scherm schildert. Wees creatief!

## Rubriek

| Criteria | Voorbeeldig                | Voldoende                 | Moet worden verbeterd |
| -------- | ------------------------ | ------------------------ | ----------------- |
|          | Er wordt een volledig spel gepresenteerd | De game is erg minimaal | De game bevat bugs |
