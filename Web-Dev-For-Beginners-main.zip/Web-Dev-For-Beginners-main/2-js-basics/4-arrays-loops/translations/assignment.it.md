# Ciclo su un Array

## Istruzioni

Creare un programma che elenchi ogni terzo numero tra 1-20 e lo stampi alla console.

> SUGGERIMENTO: usare un ciclo for e modificare l'espressione di iterazione

## Rubrica

| Criterio | Eccellente                              | Sufficiente                 | Necessita miglioramenti              |
| -------- | --------------------------------------- | ------------------------ | ------------------------------ |
|          | Il programma viene eseguito correttamente ed è commentato |Il programma non è commentato | Il programma è incompleto o presenta bug |