# Datentypen üben

## Anleitung

Stellen Sie sich vor, Sie bauen einen Einkaufswagen. Schreiben Sie eine Dokumentation zu den Datentypen, die Sie benötigen, um Ihr Einkaufserlebnis zu vervollständigen. Wie sind Sie zu Ihren Entscheidungen gekommen?

## Rubrik

Kriterien | Vorbildlich | Angemessen | Muss verbessert werden
--- | --- | --- | - |
|| Die sechs Datentypen werden aufgelistet und detailliert untersucht, wobei ihre Verwendung dokumentiert wird. | Vier Datentypen werden untersucht. | Zwei Datentypen werden untersucht. |