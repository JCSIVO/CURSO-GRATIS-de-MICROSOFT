# Latihan Jenis Data

## Arahan

Bayangkan anda sedang membina keranjang belanja. Tulis beberapa dokumentasi mengenai jenis data yang anda perlukan untuk melengkapkan pengalaman membeli-belah anda. Bagaimana anda sampai pada pilihan anda?

## Rubrik

Kriteria | Contoh | Mencukupi | Usaha Lagi
--- | --- | --- | -- |
||Enam jenis data disenaraikan dan diterokai secara terperinci, mendokumentasikan penggunaannya|Empat jenis data diterokai|Duo jenis data diterokai|