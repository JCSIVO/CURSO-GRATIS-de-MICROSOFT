# Types de données Pratique

## Instructions

Imaginez que vous construisez un panier d'achat. Écrivez une documentation sur les types de données dont vous auriez besoin pour compléter votre expérience d'achat. Comment êtes vous arrivé à vos choix?

## Rubrique

Critères |Exemplaire |Adéquat | Besoin d'amélioration
--- |--- |--- |- |
|| Les six types de données sont listés et explorés en détail, documentant leur utilisation | Quatre types de données sont explorés | Deux types de données sont explorés |