# Introduzione a JavaScript

JavaScript è il linguaggio del web. In queste quattro lezioni, si impareranno le sue basi.

### Argomenti

1. [Variabili e Tipi di Dato](../1-data-types/translations/README.it.md)
2. [Funzioni e Metodi](../2-functions-methods/translations/README.it.md)
3. [Prendere Decisioni con JavaScript](../3-making-decisions/translations/README.it.md)
4. [Array e Cicli](../4-arrays-loops/translations/README.it.md)

### Crediti

Queste lezioni sono state scritte con il  ♥️ da [Jasmine Greenaway](https://twitter.com/paladique), [Christopher Harrison](https://twitter.com/geektrainer) e [Chris Noring](https://twitter.com/chris_noring)