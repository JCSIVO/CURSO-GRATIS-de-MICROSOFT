# Pengenalan kepada JavaScript

JavaScript adalah bahasa web. Dalam empat pelajaran ini, anda akan mengetahui asasnya.

### Topik

1. [Pemboleh ubah dan Jenis Data](../1-data-types/translations/README.ms.md)
2. [Fungsi dan Kaedah](../2-functions-methods/translations/README.ms.md)
3. [Membuat Keputusan dengan JavaScript](../3-making-decisions/translations/README.ms.md)
4. [Susunan dan Gelung](../4-arrays-loops/translations/README.ms.md)

### Kredit

Pelajaran ini ditulis dengan ♥️ oleh [Jasmine Greenaway](https://twitter.com/paladique), [Christopher Harrison](https://twitter.com/geektrainer) dan [Chris Noring](https://twitter.com/chris_noring)