# Inleiding tot JavaScript

JavaScript is de taal van het web. In deze vier lessen leert u de basisprincipes.

### Onderwerpen

1. [Variabelen en Gegevenstypen](../1-data-types/translations/README.nl.md)
2. [Functies en Methoden](../2-functions-methods/translations/README.nl.md)
3. [Beslissingen nemen met JavaScript](../3-making-decisions/translations/README.nl.md)
4. [Arrays en Lussen](../4-arrays-loops/translations/README.nl.md)

### Credits

Deze lessen zijn geschreven met ♥ door [Jasmine Greenaway](https://twitter.com/paladique), [Christopher Harrison](https://twitter.com/geektrainer) en [Chris Noring](https://twitter.com/chris_noring)