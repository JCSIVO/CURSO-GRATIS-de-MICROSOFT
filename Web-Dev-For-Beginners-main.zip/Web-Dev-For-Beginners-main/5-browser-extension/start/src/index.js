//1
// campi del form
// risultati

//6
//chiamata API

//5
//imposta la chiave api e la regione per l'utente

//4
// gestisce l'invio del form

//3 controlli iniziali

//2
// imposta i listeners e la partenza dell'app
