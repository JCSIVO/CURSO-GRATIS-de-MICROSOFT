# Menggunakan API

## Arahan

API sangat menyeronokkan untuk dimainkan. Berikut adalah [senarai banyak percuma](https://github.com/public-apis/public-apis). Pilih dan API, dan buat pelanjutan penyemak imbas yang menyelesaikan masalah. Masalah kecil mungkin kerana tidak mempunyai gambar haiwan peliharaan yang cukup (jadi, cubalah [API CEO anjing](https://dog.ceo/dog-api/)) atau sesuatu yang lebih besar - bersenang-senang!

## Rubrik

| Kriteria | Contoh                                                                  | Mencukupi                                 | Usaha Lagi       |
| -------- | -------------------------------------------------------------------------- | ---------------------------------------- | ----------------------- |
|          | Pelanjutan penyemak imbas yang lengkap dihantar menggunakan API dari senarai di atas | Pelanjutan penyemak imbas separuh dihantar | Penyerahan mempunyai pepijat |