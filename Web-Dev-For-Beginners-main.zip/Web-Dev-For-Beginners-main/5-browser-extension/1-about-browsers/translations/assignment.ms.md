# Mengayakan semula penlanjut penyemak imbas

## Arahan

Pangkalan kode untuk peluasan ini dilengkapi dengan gaya, tetapi anda tidak perlu menggunakannya; jadikan peluasan anda sendiri dengan menyusun semula dengan mengedit fail cssnya.

## Rubrik

| Kriteria | Contoh                                    | Mencukupi              | Usaha Lagi |
| -------- | -------------------------------------------- | --------------------- | ----------------- |
|          | Kod dihantar dengan gaya baharu yang berfungsi | Gaya tidak lengkap | Gaya mempunyai pepijat  |