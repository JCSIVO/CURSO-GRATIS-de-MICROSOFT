# Cambia el estilo de tu extensión

## Instrucciones

El código base para esta extensión viene completo con estilos, pero no es necesario que los uses; haga suya su extensión al cambiarle el estilo editando su archivo css.

## Rúbrica

| Criterios | Ejemplar | Adecuado | Necesita mejorar |
| -------- | -------------------------------------------- | --------------------- | ----------------- |
| | El código se envía con nuevos estilos funcionales | El estilo está incompleto | Los estilos tienen errores |