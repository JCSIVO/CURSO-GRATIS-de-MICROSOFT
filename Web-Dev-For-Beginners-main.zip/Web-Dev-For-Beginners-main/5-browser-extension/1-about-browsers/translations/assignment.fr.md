# Restylez votre extension

## Instructions

La base de code de cette extension est fournie avec des styles, mais vous n'êtes pas obligé de les utiliser ; personnalisez votre extension en la restylant en éditant son fichier css.

## Rubrique

| Critères | Exemplaire                                    | Adéquat              | Besoin d'amélioration |
| -------- | -------------------------------------------- | --------------------- | ----------------- |
|          | Le code est soumis avec de nouveaux styles fonctionnels | Le style est incomplet | Les styles sont bogués  |