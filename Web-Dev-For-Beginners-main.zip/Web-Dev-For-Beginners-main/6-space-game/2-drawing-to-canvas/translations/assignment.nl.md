# Speel met de Canvas API

## Instructies

Kies een element van de Canvas API en maak er iets interessants omheen. Kunt u een kleine melkweg van herhaalde sterren creëren? Kunt u een interessante textuur van gekleurde lijnen maken? U kunt CodePen bekijken voor inspiratie (maar kopieer niet)

## Rubriek

| Criteria | Voorbeeldig                                                 | Voldoende                            | Moet worden verbeterd     |
| -------- | --------------------------------------------------------- | ----------------------------------- | --------------------- |
|          | Code wordt ingediend met een interessante textuur of vorm| Code is ingediend, maar wordt niet uitgevoerd | Code is niet verzonden |