# Main dengan Canvas API

## Arahan

Pilih satu elemen API Canvas dan buat sesuatu yang menarik di sekitarnya. Bolehkah anda membuat galaksi kecil bintang berulang? Bolehkah anda membuat tekstur garis berwarna yang menarik? Anda boleh melihat CodePen untuk mendapatkan inspirasi (tetapi jangan menyalin)

## Rubrik

| Kriteria | Contoh                                                 | Mencukupi                            | Usaha Lagi     |
| -------- | --------------------------------------------------------- | ----------------------------------- | --------------------- |
|          | Kod dihantar menunjukkan tekstur atau bentuk yang menarik | Kod dihantar, tetapi tidak dijalankan | Kod tidak dihantar |