# Komen Kod Anda

## Arahan

Periksa fail /app.js semasa anda di folder permainan anda, dan cari cara untuk mengomentarinya dan rapi. Sangat mudah bagi kod untuk tidak terkawal, dan sekarang adalah peluang yang baik untuk menambahkan komen untuk memastikan bahawa anda mempunyai kod yang dapat dibaca sehingga anda dapat menggunakannya kemudian.

## Rubrik

| Kriteria | Contoh                                                          | Mencukupi                              | Usaha Lagi                                             |
| -------- | ------------------------------------------------------------------ | ------------------------------------- | -------------------------------------------------------------- |
|          | Kod `app.js` dikomentari sepenuhnya dan disusun menjadi blok logik | Kod `app.js` diberi komen yang mencukupi | Kod `app.js` agak tidak teratur dan tidak mempunyai komen yang baik |