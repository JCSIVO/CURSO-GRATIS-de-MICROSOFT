## Track translation progress by opening a draft PR using this template and checking off the translations completed

Each lesson includes a translation of the README.md and the Assignment.md file, if available. Only mark the lesson complete if both those files are translated per lesson, please.

- [ ] 1
- [ ] 1-1
- [ ] 1-2
- [ ] 1-3
- [ ] 2
- [ ] 2
- [ ] 2-1
- [ ] 2-2
- [ ] 2-3
- [ ] 2-4
- [ ] 3
- [ ] 3-1
- [ ] 3-2
- [ ] 3-3
- [ ] 4
- [ ] 4-1
- [ ] 5
- [ ] 5-1
- [ ] 5-2
- [ ] 5-3
- [ ] 6
- [ ] 6-1
- [ ] 6-2
- [ ] 6-3
- [ ] 6-4
- [ ] 6-5
- [ ] 6-6
- [ ] 7
- [ ] 7-1
- [ ] 7-2
- [ ] 7-3
- [ ] 7-4

- [ ] Quiz (add a file in the quiz-app with all localizations)
