# Berlatih HTML anda: Bina mockup blog

## Arahan

Bayangkan anda merancang, atau merancang semula, laman web peribadi anda. Buat markup grafik laman web anda, dan kemudian tuliskan markup HTML yang akan anda gunakan untuk membina pelbagai elemen laman web ini. Anda boleh melakukannya di atas kertas, dan mengimbasnya, atau menggunakan perisian pilihan anda, pastikan anda memasukkan kod HTML dengan tangan.

## Rubrik

| Kriteria | Contoh                                                                           | Mencukupi                                                                         | Usaha Lagi                                                                 |
| -------- | ----------------------------------------------------------------------------------- | -------------------------------------------------------------------------------- | --------------------------------------------------------------------------------- |
|          | Susun atur blog ditunjukkan secara visual dengan sekurang-kurangnya 10 elemen markup dipaparkan | Susun atur blog ditunjukkan secara visual dengan sekitar 5 elemen markup ditampilkan | Susun atur blog ditunjukkan secara visual dengan paling banyak 3 elemen markup dipaparkan |