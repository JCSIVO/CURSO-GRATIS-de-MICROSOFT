# Bekerja sedikit dengan DOM

## Arahan

Mengkaji DOM sedikit dengan 'menerapkan' elemen DOM. Lawati laman MDN [senarai antara muka DOM](https://developer.mozilla.org/docs/Web/API/Document_Object_Model) dan pilih satu. Cari ia digunakan di laman web di web, dan tulis penjelasan bagaimana ia digunakan.

## Rubrik

| Kriteria | Contoh                                     | Mencukupi                                         | Usaha Lagi       |
| -------- | --------------------------------------------- | ------------------------------------------------ | ----------------------- |
|          | Penulisan perenggan dibentangkan, dengan contoh | Penulisan perenggan dibentangkan, tanpa contoh | Tiada penulisan perenggan dibentangkan |
